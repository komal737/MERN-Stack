function Login() {
  return (
    <div>
      <h1>Welcome to login page</h1>
      <p>Lorem ipsum dolor sit amet.</p>
    </div>
  );
}

export default Login;
